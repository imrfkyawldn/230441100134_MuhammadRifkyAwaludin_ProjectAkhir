/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projekperpustakaan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTable;

/**
 *
 * @author Aldinn
 */

public class DataBuku extends javax.swing.JFrame {
    Connection conn;
    private DefaultTableModel model;
    
    public DataBuku() {
        initComponents();
        setLocationRelativeTo(null);
        conn = koneksi.getConnection();

        model = new DefaultTableModel();
        tbl_databuku.setModel(model);
        
        model.addColumn("Kode Buku");
        model.addColumn("Nama Buku");
        model.addColumn("Pengarang");
        model.addColumn("Penerbit");
        model.addColumn("Tahun Terbit");
        model.addColumn("Jumlah");
        
        loadData();
        
        tbl_databuku.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent evt) {
            int selectedRow = tbl_databuku.getSelectedRow(); // Mendapatkan baris yang dipilih
                if (selectedRow != -1) { // Pastikan ada baris yang dipilih
                    tf_kodebuku_databuku.setText(model.getValueAt(selectedRow, 0).toString()); 
                    tf_namabuku_databuku.setText(model.getValueAt(selectedRow, 1).toString()); 
                    tf_pengarang_databuku.setText(model.getValueAt(selectedRow, 2).toString()); 
                    tf_penerbit_databuku.setText(model.getValueAt(selectedRow, 3).toString()); 
                    tf_tahunterbit_databuku.setText(model.getValueAt(selectedRow, 4).toString()); 
                    tf_jumlah_databuku.setText(model.getValueAt(selectedRow, 5).toString()); 
                }
            }
        });   
    }
    
    //Load Data Tabel Data Buku
    public void loadData() {
        DefaultTableModel model = (DefaultTableModel) tbl_databuku.getModel();
    model.setRowCount(0); // Hapus data lama
        try {
            String sql = "SELECT * FROM data_buku";
            Statement s = conn.createStatement();
            ResultSet r = s.executeQuery(sql);
            while (r.next()) {
                String kodeBuku = r.getString("kode_buku");
                String namaBuku = r.getString("nama_buku");
                String pengarang = r.getString("pengarang");
                String penerbit = r.getString("penerbit");
                String tahunTerbit = r.getString("tahun_terbit");
                String jumlah = r.getString("jumlah");
                model.addRow(new Object[]{kodeBuku, namaBuku, pengarang, penerbit, tahunTerbit, jumlah});
            }
            r.close();
            s.close();
        } catch (SQLException e) {
            System.out.println("Gagal Memuat Data Buku : " + e.getMessage());
        }
    }
    //End Load Data Tabel Data Buku
    
    //Auto Number Kode Buku
    public void autonumber(){
            try {
            conn = koneksi.getConnection();
            Statement s = conn.createStatement();
            String sql = "SELECT kode_buku FROM data_buku ORDER BY kode_buku DESC LIMIT 1";
            ResultSet r = s.executeQuery(sql);

            if (r.next()) {
                // Ambil angka di akhir kode_supp, apapun prefiksnya
                String kode_buku = r.getString("kode_buku").replaceAll("\\D", ""); // Hapus huruf
                int numKode = 0;
                try {
                    numKode = Integer.parseInt(kode_buku);
                } catch (NumberFormatException e) {
                    System.out.println("Format kode buku tidak valid : " + e.getMessage());
                }

                // Tambahkan 1 ke kode buku terakhir
                String KB = String.valueOf(numKode + 1);
                String Nol = "";

                if (KB.length() == 1) {
                    Nol = "000";
                } else if (KB.length() == 2) {
                    Nol = "00";
                } else if (KB.length() == 3) {
                    Nol = "0";
                }

                tf_kodebuku_databuku.setText("KB" + Nol + KB);
            } else {
                // Jika tidak ada data, mulai dari BK0001
                tf_kodebuku_databuku.setText("KB0001");
            }
            r.close();
            s.close();
        } catch (SQLException e) {
            System.out.println("autonumber error : " + e.getMessage());
        }
    }
    //End Auto Number Kode Buku
    
    //Simpan Data buku
    public void SimpanDataBuku() {
        if (tf_kodebuku_databuku.getText().isEmpty() || tf_namabuku_databuku.getText().isEmpty() || 
        tf_pengarang_databuku.getText().isEmpty() || tf_penerbit_databuku.getText().isEmpty() || 
        tf_tahunterbit_databuku.getText().isEmpty() || tf_jumlah_databuku.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi Data Buku!");
        return;
    }

    // Validasi agar nama buku, pengarang, penerbit, dan tahun terbit tidak hanya berisi spasi
    if (tf_namabuku_databuku.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Masukkan nama buku dengan benar! Tidak boleh kosong atau hanya spasi.");
        return;
    }
    if (tf_pengarang_databuku.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Masukkan nama pengarang dengan benar! Tidak boleh kosong atau hanya spasi.");
        return;
    }
    if (tf_penerbit_databuku.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Masukkan nama penerbit dengan benar! Tidak boleh kosong atau hanya spasi.");
        return;
    }
    if (tf_tahunterbit_databuku.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Masukkan tahun terbit dengan benar! Tidak boleh kosong atau hanya spasi.");
        return;
    }

    // Validasi jumlah buku
    int jumlah;
    try {
        jumlah = Integer.parseInt(tf_jumlah_databuku.getText());
        if (jumlah < 0) { // Validasi jumlah negatif
            JOptionPane.showMessageDialog(this, "Masukkan jumlah yang benar (tidak boleh negatif)!");
            return;
        }
    } catch (NumberFormatException e) { // Jika input bukan angka
        JOptionPane.showMessageDialog(this, "Masukkan jumlah yang benar (hanya angka)!");
        return;
    }

    // Konfirmasi penyimpanan data
    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menambahkan data buku?", "Konfirmasi Tambah", JOptionPane.YES_NO_OPTION);
    if (confirm == JOptionPane.YES_OPTION) {
        try {
            String sql = "INSERT INTO data_buku (kode_buku, nama_buku, pengarang, penerbit, tahun_terbit, jumlah) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tf_kodebuku_databuku.getText());
            ps.setString(2, tf_namabuku_databuku.getText());
            ps.setString(3, tf_pengarang_databuku.getText());
            ps.setString(4, tf_penerbit_databuku.getText());
            ps.setString(5, tf_tahunterbit_databuku.getText());
            ps.setInt(6, jumlah); // Menggunakan variabel jumlah yang sudah divalidasi
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Buku Berhasil Disimpan.");
            loadData(); // Memuat ulang data
            resetForm(); // Mereset form
        } catch (SQLException e) {
            System.out.println("Gagal Menyimpan Data Buku: " + e.getMessage());
        }
    }
    }
    //End Simpan Data buku
    
    //Update Data buku
    public void PerbaruiDataBuku() {
        if (tf_namabuku_databuku.getText().isEmpty() || tf_pengarang_databuku.getText().isEmpty() || tf_penerbit_databuku.getText().isEmpty() || tf_tahunterbit_databuku.getText().isEmpty() || tf_jumlah_databuku.getText().isEmpty()) {
           JOptionPane.showMessageDialog(this, "Tolong Lengkapi Data Buku Yang Akan Diubah!");
           return;
       }

       int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin mengubah Sata Buku?", "Konfirmasi Ubah", JOptionPane.YES_NO_OPTION);
       if (confirm == JOptionPane.YES_OPTION) {
           try {
               String sql = "UPDATE data_buku SET nama_buku = ?, pengarang = ?, penerbit = ?, tahun_terbit = ?, jumlah = ? WHERE kode_buku = ?";
               PreparedStatement ps = conn.prepareStatement(sql);
               ps.setString(1, tf_namabuku_databuku.getText());
               ps.setString(2, tf_pengarang_databuku.getText());
               ps.setString(3, tf_penerbit_databuku.getText());
               ps.setString(4, tf_tahunterbit_databuku.getText());
               ps.setString(5, tf_jumlah_databuku.getText());
               ps.setString(6, tf_kodebuku_databuku.getText()); 
               ps.executeUpdate();
               JOptionPane.showMessageDialog(this, "Data Berhasil Diubah");
               loadData();
               resetForm();
           } catch (SQLException e) {
               System.out.println("Gagal Menyimpan Data: " + e.getMessage());
           }
        }
    }
    //End Update Data buku
    
    //Delete Data buku
    public void HapusDataBuku() {
    if (tf_kodebuku_databuku.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong pilih buku yang akan dihapus!");
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin menghapus data buku?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM data_buku WHERE kode_buku = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, tf_kodebuku_databuku.getText()); // Menggunakan setString untuk kode supplier
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Data Berhasil Dihapus");
                loadData();
                resetForm();
            } catch (SQLException e) {
                System.out.println("Gagal Menghapus Data Data Buku: " + e.getMessage());
            }
        }
    }
    //End Delete Data buku
    
    public JTable getTblDataBuku() {
    return tbl_databuku;
    }

    public void resetForm(){
        tf_kodebuku_databuku.setText("");
        tf_namabuku_databuku.setText("");
        tf_pengarang_databuku.setText("");
        tf_penerbit_databuku.setText("");
        tf_tahunterbit_databuku.setText("");
        tf_jumlah_databuku.setText("");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel_utama = new javax.swing.JPanel();
        panel_atas = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_databuku = new javax.swing.JTable();
        btn_logout_databuku = new javax.swing.JButton();
        btn_hapus_databuku = new javax.swing.JButton();
        btn_kodebuku_databuku = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        tf_searchkode_databuku = new javax.swing.JTextField();
        btn_search_databuku = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        tf_kodebuku_databuku = new javax.swing.JTextField();
        tf_namabuku_databuku = new javax.swing.JTextField();
        tf_pengarang_databuku = new javax.swing.JTextField();
        tf_penerbit_databuku = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        tf_jumlah_databuku = new javax.swing.JTextField();
        tf_tahunterbit_databuku = new javax.swing.JTextField();
        btn_perbarui_databuku = new javax.swing.JButton();
        btn_simpan_databuku2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("𝓓𝓪𝓽𝓪 𝓑𝓾𝓴𝓾");

        panel_utama.setBackground(new java.awt.Color(249, 247, 228));
        panel_utama.setOpaque(true);
        panel_utama.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel_atas.setBackground(new java.awt.Color(34, 78, 133));
        panel_atas.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panel_atas.setOpaque(true);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logobulat90.png"))); // NOI18N
        jLabel3.setText("jLabel3");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logotutwuri90.png"))); // NOI18N
        jLabel4.setText("jLabel3");

        jLabel2.setFont(new java.awt.Font("Cooper Black", 0, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(249, 247, 228));
        jLabel2.setText("DATA BUKU");

        javax.swing.GroupLayout panel_atasLayout = new javax.swing.GroupLayout(panel_atas);
        panel_atas.setLayout(panel_atasLayout);
        panel_atasLayout.setHorizontalGroup(
            panel_atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_atasLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(146, 146, 146)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 158, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );
        panel_atasLayout.setVerticalGroup(
            panel_atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_atasLayout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(panel_atasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(14, 14, 14))
            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        panel_utama.add(panel_atas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        tbl_databuku.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        tbl_databuku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Kode Buku", "Nama Buku", "Pengarang", "Penerbit", "Tahun Terbit", "Jumlah"
            }
        ));
        jScrollPane1.setViewportView(tbl_databuku);

        panel_utama.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 790, 120));

        btn_logout_databuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_logout_databuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_logout_databuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_logout_databuku.setText("LogOut");
        btn_logout_databuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logout_databukuActionPerformed(evt);
            }
        });
        panel_utama.add(btn_logout_databuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, -1, 30));

        btn_hapus_databuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_hapus_databuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_hapus_databuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_hapus_databuku.setText("Hapus");
        btn_hapus_databuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapus_databukuActionPerformed(evt);
            }
        });
        panel_utama.add(btn_hapus_databuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 510, -1, 30));

        btn_kodebuku_databuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_kodebuku_databuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_kodebuku_databuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_kodebuku_databuku.setText("Kode Buku");
        btn_kodebuku_databuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kodebuku_databukuActionPerformed(evt);
            }
        });
        panel_utama.add(btn_kodebuku_databuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 510, -1, 30));

        jPanel1.setBackground(new java.awt.Color(249, 247, 228));
        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray));

        jLabel7.setBackground(new java.awt.Color(204, 204, 204));
        jLabel7.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(34, 78, 133));
        jLabel7.setText("SEARCH KODE BUKU");

        tf_searchkode_databuku.setBackground(new java.awt.Color(249, 247, 228));

        btn_search_databuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_search_databuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_search_databuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_search_databuku.setText("Search");
        btn_search_databuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_search_databukuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(tf_searchkode_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_search_databuku)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_search_databuku, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tf_searchkode_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        panel_utama.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 140, 260, 70));

        jPanel2.setBackground(new java.awt.Color(34, 78, 133));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(249, 247, 228));
        jLabel5.setText("Kode Buku       :");

        jLabel6.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(249, 247, 228));
        jLabel6.setText("Nama Buku      :");

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(249, 247, 228));
        jLabel8.setText("Pengarang       :");

        tf_kodebuku_databuku.setEditable(false);
        tf_kodebuku_databuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_kodebuku_databukuActionPerformed(evt);
            }
        });

        tf_penerbit_databuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_penerbit_databukuActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(249, 247, 228));
        jLabel9.setText("Penerbit           :");

        jLabel10.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(249, 247, 228));
        jLabel10.setText("Tahun Terbit    :");

        jLabel11.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(249, 247, 228));
        jLabel11.setText("Jumlah             :");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_pengarang_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_namabuku_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_kodebuku_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_jumlah_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_tahunterbit_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_penerbit_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(74, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(tf_kodebuku_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(tf_namabuku_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(tf_pengarang_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(tf_penerbit_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(tf_tahunterbit_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(tf_jumlah_databuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(8, Short.MAX_VALUE))
        );

        panel_utama.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 790, 140));

        btn_perbarui_databuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_perbarui_databuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_perbarui_databuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_perbarui_databuku.setText("Perbarui");
        btn_perbarui_databuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_perbarui_databukuActionPerformed(evt);
            }
        });
        panel_utama.add(btn_perbarui_databuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 510, -1, 30));

        btn_simpan_databuku2.setBackground(new java.awt.Color(34, 78, 133));
        btn_simpan_databuku2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_simpan_databuku2.setForeground(new java.awt.Color(249, 247, 228));
        btn_simpan_databuku2.setText("Simpan");
        btn_simpan_databuku2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpan_databuku2ActionPerformed(evt);
            }
        });
        panel_utama.add(btn_simpan_databuku2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 510, -1, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_utama, javax.swing.GroupLayout.DEFAULT_SIZE, 810, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_utama, javax.swing.GroupLayout.PREFERRED_SIZE, 554, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tf_kodebuku_databukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_kodebuku_databukuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_kodebuku_databukuActionPerformed

    private void tf_penerbit_databukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_penerbit_databukuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_penerbit_databukuActionPerformed

    private void btn_logout_databukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logout_databukuActionPerformed
        // TODO add your handling code here:
        Login loginFrame = new Login();
        loginFrame.setVisible(true);
        loginFrame.pack();
        loginFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btn_logout_databukuActionPerformed

    private void btn_kodebuku_databukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kodebuku_databukuActionPerformed
        // TODO add your handling code here:
        autonumber();
    }//GEN-LAST:event_btn_kodebuku_databukuActionPerformed

    private void btn_search_databukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_search_databukuActionPerformed
        // TODO add your handling code here:
        String kodeBuku = tf_searchkode_databuku.getText();
    
        if (kodeBuku.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tolong masukkan kode buku untuk mencari!");
            return;
            }

            try {
                // Query diarahkan ke tabel peminjaman_buku
                String sql = "SELECT kode_buku, nama_buku, pengarang, penerbit, tahun_terbit, jumlah FROM data_buku WHERE kode_buku = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, kodeBuku);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    // Mengisi textfield dengan data yang ditemukan
                    tf_kodebuku_databuku.setText(rs.getString("kode_buku"));
                    tf_namabuku_databuku.setText(rs.getString("nama_buku"));
                    tf_pengarang_databuku.setText(rs.getString("pengarang"));
                    tf_penerbit_databuku.setText(rs.getString("penerbit"));
                    tf_tahunterbit_databuku.setText(rs.getString("tahun_terbit"));
                    tf_jumlah_databuku.setText(rs.getString("jumlah"));
                } else {
                    JOptionPane.showMessageDialog(this, "Data dengan kode pinjam tersebut tidak ditemukan!");
                    resetForm();
                }
            } catch (SQLException e) {
                System.out.println("Gagal mencari data peminjaman: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_search_databukuActionPerformed

    private void btn_hapus_databukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapus_databukuActionPerformed
        // TODO add your handling code here:
        HapusDataBuku();
    }//GEN-LAST:event_btn_hapus_databukuActionPerformed

    private void btn_perbarui_databukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_perbarui_databukuActionPerformed
        // TODO add your handling code here:
        PerbaruiDataBuku();
    }//GEN-LAST:event_btn_perbarui_databukuActionPerformed

    private void btn_simpan_databuku2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpan_databuku2ActionPerformed
        // TODO add your handling code here:
        SimpanDataBuku();
    }//GEN-LAST:event_btn_simpan_databuku2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DataBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DataBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DataBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DataBuku.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DataBuku().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_hapus_databuku;
    private javax.swing.JButton btn_kodebuku_databuku;
    private javax.swing.JButton btn_logout_databuku;
    private javax.swing.JButton btn_perbarui_databuku;
    private javax.swing.JButton btn_search_databuku;
    private javax.swing.JButton btn_simpan_databuku2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panel_atas;
    private javax.swing.JPanel panel_utama;
    private javax.swing.JTable tbl_databuku;
    private javax.swing.JTextField tf_jumlah_databuku;
    private javax.swing.JTextField tf_kodebuku_databuku;
    private javax.swing.JTextField tf_namabuku_databuku;
    private javax.swing.JTextField tf_penerbit_databuku;
    private javax.swing.JTextField tf_pengarang_databuku;
    private javax.swing.JTextField tf_searchkode_databuku;
    private javax.swing.JTextField tf_tahunterbit_databuku;
    // End of variables declaration//GEN-END:variables

    JTable getTblStok() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void getTbldataBuku(JTable tbl_databuku) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

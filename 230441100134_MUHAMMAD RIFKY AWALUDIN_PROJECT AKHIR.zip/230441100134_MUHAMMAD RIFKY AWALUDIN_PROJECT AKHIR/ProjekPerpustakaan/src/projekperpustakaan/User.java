/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projekperpustakaan;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Aldinn
 */

public class User extends javax.swing.JFrame {
    
    Connection conn;
    private DefaultTableModel model;
    private DefaultTableModel model2;
    private DefaultTableModel model3;

    /**
     * Creates new form User
     */
    
    public User() {
        initComponents();  // Inisialisasi komponen GUI terlebih dahulu
        setLocationRelativeTo(null);
        conn = koneksi.getConnection();
        
        // Inisialisasi model untuk tabel stok buku
        model = new DefaultTableModel();
        tbl_informasibuku.setModel(model);
        
        model.addColumn("Kode Buku");
        model.addColumn("Nama Buku");
        model.addColumn("Pengarang");
        model.addColumn("Penerbit");
        model.addColumn("Tahun Terbit");
        model.addColumn("Jumlah");
        
        model2 = new DefaultTableModel();
        tbl_peminjamanbuku.setModel(model2);
        
        model2.addColumn("Kode Pinjam");
        model2.addColumn("Nama Peminjam");
        model2.addColumn("Nisn");
        model2.addColumn("Kode Buku");
        model2.addColumn("Nama Buku");
        model2.addColumn("Pengarang");
        model2.addColumn("Penerbit");
        model2.addColumn("Tahun Terbit");
//        model2.addColumn("Jumlah");
        
        model3 = new DefaultTableModel();
        tbl_pengembalianbuku.setModel(model3);
        model3.addColumn("Kode Pinjam");
        model3.addColumn("Nama Peminjam");
        model3.addColumn("Kode Buku");
        model3.addColumn("Nama Buku");


        // Memuat data dari tabel 'input'
        loadData();
        loadData2();
        loadData3();

        tbl_pengembalianbuku.addMouseListener(new MouseAdapter() {
        @Override
            public void mouseClicked(MouseEvent evt) {
                int selectedRow = tbl_pengembalianbuku.getSelectedRow(); // Mendapatkan baris yang dipilih
                if (selectedRow != -1) { // Pastikan ada baris yang dipilih
                    tf_kodepinjam_pengembalianbuku.setText(model3.getValueAt(selectedRow, 0).toString());
                    tf_nama_pengembalianbuku.setText(model3.getValueAt(selectedRow, 1).toString()); 
                    tf_kodebuku_pengembalianbuku.setText(model3.getValueAt(selectedRow, 2).toString()); 
                    tf_namabuku_pengembalianbuku.setText(model3.getValueAt(selectedRow, 3).toString()); 
                }
            }

        });
    }
    
    public void loadData() {
        // Mengosongkan tabel sebelum memuat data baru
        model.setRowCount(0);

        try {
            // Query SQL untuk mengambil data dari tabel 'input'
            String sql = "SELECT * FROM data_buku"; // Gunakan tabel yang sesuai
            Statement s = conn.createStatement();
            ResultSet r = s.executeQuery(sql);

            // Menambahkan data ke dalam model tabel
            while (r.next()) {
                String kodeBuku1 = r.getString("kode_buku");
                String namaBuku1 = r.getString("nama_buku");
                String pengarang1 = r.getString("pengarang");
                String penerbit1 = r.getString("penerbit");
                String tahunTerbit1 = r.getString("tahun_terbit");
                String jumlah1 = r.getString("jumlah");

                // Menambahkan baris data ke tabel
                model.addRow(new Object[]{kodeBuku1, namaBuku1, pengarang1, penerbit1, tahunTerbit1, jumlah1});
            }

            // Menutup resources
            r.close();
            s.close();
        } catch (SQLException e) {
            // Menangani kesalahan SQL
            System.out.println("Gagal Memuat Data Buku: " + e.getMessage());
        }
    }
    
    public void loadData2() {
        // Mengosongkan tabel sebelum memuat data baru
        model2.setRowCount(0);
        DefaultTableModel model2 = (DefaultTableModel) tbl_peminjamanbuku.getModel();
        
        try {
            // Query SQL untuk mengambil data dari tabel 'input'
            String sql = "SELECT * FROM peminjaman_buku"; // Gunakan tabel yang sesuai
            Statement s = conn.createStatement();
            ResultSet r = s.executeQuery(sql);

            // Menambahkan data ke dalam model tabel
            while (r.next()) {
                String kodePinjam = r.getString("kode_pinjam");
                String namaPeminjam = r.getString("nama_peminjam");
                String nisn = r.getString("nisn");
                String kodeBuku = r.getString("kode_buku2");
                String namaBuku = r.getString("nama_buku2");
                String pengarang = r.getString("pengarang2");
                String penerbit = r.getString("penerbit2");
                String tahunTerbit = r.getString("tahun_terbit2");
//                String jumlah2 = r.getString("jumlah2");

                // Menambahkan baris data ke tabel
                model2.addRow(new Object[]{kodePinjam, namaPeminjam, nisn, kodeBuku, namaBuku, pengarang, penerbit, tahunTerbit});
            }

            // Menutup resources
            r.close();
            s.close();
        } catch (SQLException e) {
            // Menangani kesalahan SQL
            System.out.println("Gagal Memuat Data Peminjaman Buku: " + e.getMessage());
        }
    }
    
    public void loadData3() {
        // Mengosongkan tabel sebelum memuat data baru
        model3.setRowCount(0);

        try {
            // Query SQL untuk mengambil data dari tabel 'input'
            String sql = "SELECT * FROM pengembalian_buku";
            Statement s = conn.createStatement();
            ResultSet r = s.executeQuery(sql);

            // Menambahkan data ke dalam model tabel
            while (r.next()) {
                String kodePinjam = r.getString("kode_pinjam");
                String namaPeminjam = r.getString("nama_peminjam");
                String kodeBuku2 = r.getString("kode_buku2");
                String namaBuku2 = r.getString("nama_buku2");

                // Menambahkan baris data ke tabel
                model3.addRow(new Object[]{kodePinjam, namaPeminjam, kodeBuku2, namaBuku2});
            }

            // Menutup resources
            r.close();
            s.close();
        } catch (SQLException e) {
            // Menangani kesalahan SQL
            System.out.println("Gagal Memuat Data Pengembalian Buku: " + e.getMessage());
        }
    }
    
    // Auto Number Peminjaman Buku
    public void autonumber(){
        try {
        conn = koneksi.getConnection();
        Statement s = conn.createStatement();
        String sql = "SELECT kode_pinjam FROM peminjaman_buku ORDER BY kode_pinjam DESC LIMIT 1";
        ResultSet r = s.executeQuery(sql);

            if (r.next()) {

                String kode_buku = r.getString("kode_pinjam").replaceAll("\\D", ""); // Hapus huruf
                int numKode = 0;
                try {
                    numKode = Integer.parseInt(kode_buku);
                } catch (NumberFormatException e) {
                    System.out.println("Format kode input tidak valid: " + e.getMessage());
                }

                // Tambahkan 1 ke kode buku terakhir
                String KP = String.valueOf(numKode + 1);
                String Nol = "";

                if (KP.length() == 1) {
                    Nol = "000";
                } else if (KP.length() == 2) {
                    Nol = "00";
                } else if (KP.length() == 3) {
                    Nol = "0";
                }

                tf_kodepinjam_peminjamanbuku.setText("KP" + Nol + KP);
            } else {
                // Jika tidak ada data, mulai dari BK0001
                tf_kodepinjam_peminjamanbuku.setText("KP0001");
            }
            r.close();
            s.close();
        } catch (SQLException e) {
            System.out.println("autonumber error: " + e.getMessage());
        }
    }
    // End Auto Number Peminjaman Buku

    //Simpan Data Pinjam Buku
    public void PinjamBuku() {
    // Periksa apakah semua field sudah diisi
        if (tf_kodepinjam_peminjamanbuku.getText().isEmpty() || 
        tf_nama_peminjamanbuku.getText().isEmpty() || 
        tf_nisn_peminjamanbuku.getText().isEmpty() || 
        tf_kodebuku_peminjamanbuku.getText().isEmpty() || 
        tf_namabuku_peminjamanbuku.getText().isEmpty() || 
        tf_pengarang_peminjamanbuku.getText().isEmpty() || 
        tf_penerbit_peminjamanbuku.getText().isEmpty() || 
        tf_tahunterbit_peminjamanbuku.getText().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong Lengkapi Data Peminjaman!");
        return;
    }

    // Validasi nama (tidak boleh kosong atau hanya spasi)
    if (tf_nama_peminjamanbuku.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Masukkan nama dengan benar! Nama tidak boleh kosong atau hanya spasi.");
        return;
    }

    // Validasi NISN (harus angka positif)
    try {
        long nisn = Long.parseLong(tf_nisn_peminjamanbuku.getText()); // Parsing untuk memastikan angka
        if (nisn < 0) { // Jika NISN negatif
            JOptionPane.showMessageDialog(this, "Masukkan NISN dengan benar! (tidak boleh negatif)");
            return;
        }
    } catch (NumberFormatException e) { // Jika NISN bukan angka
        JOptionPane.showMessageDialog(this, "Masukkan NISN dengan benar! (hanya angka)");
        return;
    }

    // Periksa apakah NISN sudah ada di database
    try {
        String checkSql = "SELECT COUNT(*) FROM peminjaman_buku WHERE nisn = ?";
        PreparedStatement checkPs = conn.prepareStatement(checkSql);
        checkPs.setString(1, tf_nisn_peminjamanbuku.getText());
        ResultSet rs = checkPs.executeQuery();
        if (rs.next() && rs.getInt(1) > 0) {
            JOptionPane.showMessageDialog(this, "Harap masukkan NISN dengan benar! NISN ini sudah terdaftar.");
            return;
        }
    } catch (SQLException e) {
        System.out.println("Gagal memeriksa NISN: " + e.getMessage());
        return;
    }

    // Periksa apakah jumlah buku yang dipilih adalah 0
    try {
        String checkStockSql = "SELECT jumlah FROM data_buku WHERE kode_buku = ?";
        PreparedStatement checkStockPs = conn.prepareStatement(checkStockSql);
        checkStockPs.setString(1, tf_kodebuku_peminjamanbuku.getText());
        ResultSet stockRs = checkStockPs.executeQuery();

        if (stockRs.next()) {
            int stock = stockRs.getInt("jumlah");
            if (stock == 0) {
                JOptionPane.showMessageDialog(this, "Tolong pilih buku yang tersedia! Stok buku ini habis.");
                return;
            }
        }
    } catch (SQLException e) {
        System.out.println("Gagal memeriksa jumlah stok buku: " + e.getMessage());
        return;
    }

    // Konfirmasi penambahan buku ke daftar pinjaman
    int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda Yakin Akan Menambahkan Buku Ke Daftar Peminjaman?", "Konfirmasi Tambah", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // Masukkan data peminjaman ke tabel peminjaman_buku
                String sql = "INSERT INTO peminjaman_buku (kode_pinjam, nama_peminjam, nisn, kode_buku2, nama_buku2, pengarang2, penerbit2, tahun_terbit2, jumlah2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, tf_kodepinjam_peminjamanbuku.getText());
                ps.setString(2, tf_nama_peminjamanbuku.getText());
                ps.setString(3, tf_nisn_peminjamanbuku.getText());
                ps.setString(4, tf_kodebuku_peminjamanbuku.getText());
                ps.setString(5, tf_namabuku_peminjamanbuku.getText());
                ps.setString(6, tf_pengarang_peminjamanbuku.getText());
                ps.setString(7, tf_penerbit_peminjamanbuku.getText());
                ps.setString(8, tf_tahunterbit_peminjamanbuku.getText());
                ps.setInt(9, 1); // Jumlah default yang dipinjam adalah 1

                ps.executeUpdate();

                // Update jumlah buku di tabel data_buku (stok berkurang 1)
                String updateSql = "UPDATE data_buku SET jumlah = jumlah - 1 WHERE kode_buku = ? AND jumlah > 0";
                PreparedStatement updatePs = conn.prepareStatement(updateSql);
                updatePs.setString(1, tf_kodebuku_peminjamanbuku.getText());
                int rowsUpdated = updatePs.executeUpdate();

                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(this, "Buku Berhasil Dimasukkan Ke Daftar Peminjaman dan Stok Diperbarui.");
                } else {
                    JOptionPane.showMessageDialog(this, "Buku Tidak Ditemukan atau Stok Tidak Cukup!");
                }

                // Refresh data di tabel dan reset form
                loadData2();
                resetForm();
            } catch (SQLException e) {
                System.out.println("Gagal Memasukkan Buku dalam Daftar Pinjam: " + e.getMessage());
            }
        }
    }
    //End Simpan Data Pinjam Buku
    
    //Simpan Data Pengembalian Buku
    public void KembalikanBuku() {
        if (tf_kodepinjam_pengembalianbuku.getText().isEmpty() || 
            tf_nama_pengembalianbuku.getText().isEmpty() || 
            tf_kodebuku_pengembalianbuku.getText().isEmpty() || 
            tf_namabuku_pengembalianbuku.getText().isEmpty() || 
            tf_password_pengembalianbuku.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tolong Lengkapi Data Pengembalian Buku!");
            return;
        }
        try {
            // Validasi password pengguna
            String sqlPassword = "SELECT password FROM user WHERE password = ?";
            PreparedStatement psPassword = conn.prepareStatement(sqlPassword);
            psPassword.setString(1, tf_password_pengembalianbuku.getText());
            ResultSet rsPassword = psPassword.executeQuery();

            if (!rsPassword.next()) {
                JOptionPane.showMessageDialog(this, "Password salah! Harap masukkan password yang benar.");
                return;
            }

            // Konfirmasi pengembalian buku
            int confirm = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin akan mengembalikan buku ini?", "Konfirmasi Pengembalian", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    // Masukkan data ke tabel pengembalian_buku
                    String sqlInsert = "INSERT INTO pengembalian_buku (kode_pinjam, nama_peminjam, kode_buku2, nama_buku2, password) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement psInsert = conn.prepareStatement(sqlInsert);
                    psInsert.setString(1, tf_kodepinjam_pengembalianbuku.getText());
                    psInsert.setString(2, tf_nama_pengembalianbuku.getText());
                    psInsert.setString(3, tf_kodebuku_pengembalianbuku.getText());
                    psInsert.setString(4, tf_namabuku_pengembalianbuku.getText());
                    psInsert.setString(5, tf_password_pengembalianbuku.getText()); // Tambahkan password di sini
                    psInsert.executeUpdate();

                    // Hapus data dari tabel peminjaman_buku berdasarkan kode_pinjam
                    String sqlDelete = "DELETE FROM peminjaman_buku WHERE kode_pinjam = ?";
                    PreparedStatement psDelete = conn.prepareStatement(sqlDelete);
                    psDelete.setString(1, tf_kodepinjam_pengembalianbuku.getText());
                    int rowsDeleted = psDelete.executeUpdate();

                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(this, "Buku berhasil dikembalikan!");

                        // Tambahkan jumlah stok buku di tabel data_buku (jumlah + 1)
                        String sqlUpdate = "UPDATE data_buku SET jumlah = jumlah + 1 WHERE kode_buku = ?";
                        PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate);
                        psUpdate.setString(1, tf_kodebuku_pengembalianbuku.getText());
                        int rowsUpdated = psUpdate.executeUpdate();

                        if (rowsUpdated > 0) {
                            JOptionPane.showMessageDialog(this, "Stok buku berhasil diperbarui!");
                        } else {
                            JOptionPane.showMessageDialog(this, "Kode buku tidak ditemukan! Stok tidak diperbarui.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Tidak ada data yang dihapus dari tabel peminjaman.");
                    }

                    // Refresh tabel pengembalian
                    loadData3(); // Fungsi untuk memuat ulang tabel pengembalian

                    // Refresh tabel peminjaman
                    loadData2();
                    resetForm3(); 
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Gagal mengembalikan buku: " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal memvalidasi password: " + e.getMessage());
        }
    }
    //End Simpan Data Pengembalian Buku
    
    // Reset Semua Field
    public void resetForm(){
        tf_kodepinjam_peminjamanbuku.setText("");
        tf_nama_peminjamanbuku.setText("");
        tf_nisn_peminjamanbuku.setText("");
        tf_kodebuku_peminjamanbuku.setText("");
        tf_namabuku_peminjamanbuku.setText("");
        tf_pengarang_peminjamanbuku.setText("");
        tf_penerbit_peminjamanbuku.setText("");
        tf_tahunterbit_peminjamanbuku.setText("");
        tf_jumlah_peminjamanbuku.setText("");
    }
    
    public void resetForm2() {
        tf_carikodepinjam_pengembalianbuku.setText("");
        tf_kodepinjam_pengembalianbuku.setText("");
        tf_nama_pengembalianbuku.setText("");
        tf_kodebuku_pengembalianbuku.setText("");
        tf_namabuku_pengembalianbuku.setText("");
    }
        
    public void resetForm3() {
        tf_carikodepinjam_pengembalianbuku.setText("");
        tf_kodepinjam_pengembalianbuku.setText("");
        tf_nama_pengembalianbuku.setText("");
        tf_kodebuku_pengembalianbuku.setText("");
        tf_namabuku_pengembalianbuku.setText("");
        tf_password_pengembalianbuku.setText("");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel_informasibuku = new javax.swing.JTabbedPane();
        PInformasiBuku = new javax.swing.JPanel();
        panel_utama4 = new javax.swing.JPanel();
        panel_atas5 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_informasibuku = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        tf_carijudulbuku_pengembalianbuku = new javax.swing.JTextField();
        btn_caribuku_informasibuku = new javax.swing.JButton();
        btn_logout_informasibuku = new javax.swing.JButton();
        PPeminjamanBuku = new javax.swing.JPanel();
        panel_atas1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tf_kodepinjam_peminjamanbuku = new javax.swing.JTextField();
        tf_nisn_peminjamanbuku = new javax.swing.JTextField();
        tf_kodebuku_peminjamanbuku = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_peminjamanbuku = new javax.swing.JTable();
        btn_kembali_peminjamanbuku = new javax.swing.JButton();
        btn_kodepinjam_peminjamanbuku = new javax.swing.JButton();
        btn_pinjam_peminjamanbuku = new javax.swing.JButton();
        tf_nama_peminjamanbuku = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btn_pilihbuku_peminjamanbuku = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        tf_namabuku_peminjamanbuku = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        tf_pengarang_peminjamanbuku = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        tf_penerbit_peminjamanbuku = new javax.swing.JTextField();
        tf_tahunterbit_peminjamanbuku = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        tf_jumlah_peminjamanbuku = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        PPengembalianBuku = new javax.swing.JPanel();
        panel_utama1 = new javax.swing.JPanel();
        panel_atas2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        tf_kodepinjam_pengembalianbuku = new javax.swing.JTextField();
        tf_nama_pengembalianbuku = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_pengembalianbuku = new javax.swing.JTable();
        btn_kembali_pengembalianbuku = new javax.swing.JButton();
        btn_kembalikan_pengembalianbuku = new javax.swing.JButton();
        tf_namabuku_pengembalianbuku = new javax.swing.JTextField();
        tf_kodebuku_pengembalianbuku = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        tf_password_pengembalianbuku = new javax.swing.JPasswordField();
        jPanel8 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        tf_carikodepinjam_pengembalianbuku = new javax.swing.JTextField();
        btn_cari_pengembalianbuku = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        btn_batal_pengembalianbuku = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("𝓤𝓼𝓮𝓻");

        panel_informasibuku.setToolTipText("");

        PInformasiBuku.setToolTipText("INFORMASI BUKU");

        panel_utama4.setBackground(new java.awt.Color(249, 247, 228));
        panel_utama4.setOpaque(true);
        panel_utama4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel_atas5.setBackground(new java.awt.Color(34, 78, 133));
        panel_atas5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        panel_atas5.setOpaque(true);

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logobulat90.png"))); // NOI18N
        jLabel26.setText("jLabel3");

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logotutwuri90.png"))); // NOI18N
        jLabel27.setText("jLabel3");

        jLabel28.setFont(new java.awt.Font("Cooper Black", 0, 36)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(249, 247, 228));
        jLabel28.setText("INFORMASI BUKU");

        javax.swing.GroupLayout panel_atas5Layout = new javax.swing.GroupLayout(panel_atas5);
        panel_atas5.setLayout(panel_atas5Layout);
        panel_atas5Layout.setHorizontalGroup(
            panel_atas5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_atas5Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76)
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 102, Short.MAX_VALUE)
                .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );
        panel_atas5Layout.setVerticalGroup(
            panel_atas5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel_atas5Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(panel_atas5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(jLabel27))
                .addGap(14, 14, 14))
            .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        panel_utama4.add(panel_atas5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        tbl_informasibuku.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        tbl_informasibuku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Kode Buku", "Nama Buku", "Pengarang", "Penerbit", "Tahun Terbit", "Jumlah"
            }
        ));
        jScrollPane3.setViewportView(tbl_informasibuku);

        panel_utama4.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 790, 260));

        jPanel9.setBackground(new java.awt.Color(249, 247, 228));
        jPanel9.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray));

        jLabel32.setBackground(new java.awt.Color(204, 204, 204));
        jLabel32.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(34, 78, 133));
        jLabel32.setText("Cari Judul Buku");

        tf_carijudulbuku_pengembalianbuku.setBackground(new java.awt.Color(249, 247, 228));

        btn_caribuku_informasibuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_caribuku_informasibuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_caribuku_informasibuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_caribuku_informasibuku.setText("Cari");
        btn_caribuku_informasibuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_caribuku_informasibukuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(tf_carijudulbuku_pengembalianbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_caribuku_informasibuku, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tf_carijudulbuku_pengembalianbuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 1, Short.MAX_VALUE))
                    .addComponent(btn_caribuku_informasibuku, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        panel_utama4.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 250, 80));

        btn_logout_informasibuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_logout_informasibuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_logout_informasibuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_logout_informasibuku.setText("LogOut");
        btn_logout_informasibuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logout_informasibukuActionPerformed(evt);
            }
        });
        panel_utama4.add(btn_logout_informasibuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, -1, 30));

        javax.swing.GroupLayout PInformasiBukuLayout = new javax.swing.GroupLayout(PInformasiBuku);
        PInformasiBuku.setLayout(PInformasiBukuLayout);
        PInformasiBukuLayout.setHorizontalGroup(
            PInformasiBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_utama4, javax.swing.GroupLayout.DEFAULT_SIZE, 810, Short.MAX_VALUE)
        );
        PInformasiBukuLayout.setVerticalGroup(
            PInformasiBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_utama4, javax.swing.GroupLayout.PREFERRED_SIZE, 554, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        panel_informasibuku.addTab("Informasi Buku", PInformasiBuku);

        PPeminjamanBuku.setBackground(new java.awt.Color(249, 247, 228));
        PPeminjamanBuku.setToolTipText("PEMINJAMAN BUKU");

        panel_atas1.setBackground(new java.awt.Color(34, 78, 133));
        panel_atas1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logobulat90.png"))); // NOI18N
        jLabel5.setText("jLabel3");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logotutwuri90.png"))); // NOI18N
        jLabel6.setText("jLabel3");

        jLabel7.setFont(new java.awt.Font("Cooper Black", 0, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(249, 247, 228));
        jLabel7.setText("PEMINJAMAN BUKU");

        javax.swing.GroupLayout panel_atas1Layout = new javax.swing.GroupLayout(panel_atas1);
        panel_atas1.setLayout(panel_atas1Layout);
        panel_atas1Layout.setHorizontalGroup(
            panel_atas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_atas1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(64, 64, 64)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );
        panel_atas1Layout.setVerticalGroup(
            panel_atas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_atas1Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(panel_atas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(14, 14, 14))
            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel1.setText("Kode Buku        :");

        jLabel8.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel8.setText("Kode Pinjam     :");

        jLabel9.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel9.setText("Nisn                     : ");

        tf_kodepinjam_peminjamanbuku.setEditable(false);
        tf_kodepinjam_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        tf_nisn_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        tf_kodebuku_peminjamanbuku.setEditable(false);
        tf_kodebuku_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        tbl_peminjamanbuku.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        tbl_peminjamanbuku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Kode Pinjam", "Nama", "Nisn", "Kode Buku", "Nama Buku", "Pengarang", "Penerbit", "Tahun Terbit"
            }
        ));
        jScrollPane1.setViewportView(tbl_peminjamanbuku);

        btn_kembali_peminjamanbuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_kembali_peminjamanbuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_kembali_peminjamanbuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_kembali_peminjamanbuku.setText("LogOut");
        btn_kembali_peminjamanbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kembali_peminjamanbukuActionPerformed(evt);
            }
        });

        btn_kodepinjam_peminjamanbuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_kodepinjam_peminjamanbuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_kodepinjam_peminjamanbuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_kodepinjam_peminjamanbuku.setText("Kode Pinjam");
        btn_kodepinjam_peminjamanbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kodepinjam_peminjamanbukuActionPerformed(evt);
            }
        });

        btn_pinjam_peminjamanbuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_pinjam_peminjamanbuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_pinjam_peminjamanbuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_pinjam_peminjamanbuku.setText("Pinjam");
        btn_pinjam_peminjamanbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pinjam_peminjamanbukuActionPerformed(evt);
            }
        });

        tf_nama_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        jLabel11.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel11.setText("Nama                  : ");

        btn_pilihbuku_peminjamanbuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_pilihbuku_peminjamanbuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_pilihbuku_peminjamanbuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_pilihbuku_peminjamanbuku.setText("Pilih Buku");
        btn_pilihbuku_peminjamanbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pilihbuku_peminjamanbukuActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel20.setText("Nama Buku           :");

        tf_namabuku_peminjamanbuku.setEditable(false);
        tf_namabuku_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        jLabel21.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel21.setText("Pengarang            :");

        tf_pengarang_peminjamanbuku.setEditable(false);
        tf_pengarang_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        jLabel22.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel22.setText("Penerbit                 : ");

        tf_penerbit_peminjamanbuku.setEditable(false);
        tf_penerbit_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        tf_tahunterbit_peminjamanbuku.setEditable(false);
        tf_tahunterbit_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        jLabel23.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel23.setText("Tahun Penerbit    :");

        tf_jumlah_peminjamanbuku.setEditable(false);
        tf_jumlah_peminjamanbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel2.setText("Jumlah               :");

        javax.swing.GroupLayout PPeminjamanBukuLayout = new javax.swing.GroupLayout(PPeminjamanBuku);
        PPeminjamanBuku.setLayout(PPeminjamanBukuLayout);
        PPeminjamanBukuLayout.setHorizontalGroup(
            PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PPeminjamanBukuLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(panel_atas1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                        .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING)))
                        .addGap(18, 18, 18)
                        .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tf_nama_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tf_nisn_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tf_kodebuku_peminjamanbuku, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(tf_jumlah_peminjamanbuku, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tf_kodepinjam_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(45, 45, 45)
                        .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_tahunterbit_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tf_pengarang_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tf_penerbit_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tf_namabuku_peminjamanbuku, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                        .addComponent(btn_kembali_peminjamanbuku)
                        .addGap(398, 398, 398)
                        .addComponent(btn_kodepinjam_peminjamanbuku)
                        .addGap(9, 9, 9)
                        .addComponent(btn_pilihbuku_peminjamanbuku)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_pinjam_peminjamanbuku)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 796, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(14, Short.MAX_VALUE)))
        );
        PPeminjamanBukuLayout.setVerticalGroup(
            PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PPeminjamanBukuLayout.createSequentialGroup()
                .addComponent(panel_atas1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                        .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tf_kodepinjam_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                                .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(tf_nama_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(10, 10, 10)
                                .addComponent(tf_nisn_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(tf_kodebuku_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                            .addComponent(tf_namabuku_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addComponent(tf_pengarang_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(10, 10, 10)
                            .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(tf_penerbit_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(9, 9, 9)
                            .addComponent(tf_tahunterbit_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                            .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                                    .addGap(40, 40, 40)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(49, 49, 49)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(tf_jumlah_peminjamanbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PPeminjamanBukuLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 175, Short.MAX_VALUE)
                .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_kembali_peminjamanbuku)
                    .addComponent(btn_kodepinjam_peminjamanbuku)
                    .addComponent(btn_pilihbuku_peminjamanbuku)
                    .addComponent(btn_pinjam_peminjamanbuku))
                .addGap(14, 14, 14))
            .addGroup(PPeminjamanBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PPeminjamanBukuLayout.createSequentialGroup()
                    .addContainerGap(367, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(52, Short.MAX_VALUE)))
        );

        panel_informasibuku.addTab("Peminjaman Buku", PPeminjamanBuku);

        PPengembalianBuku.setToolTipText("PENGEMBALIAN BUKU");

        panel_utama1.setBackground(new java.awt.Color(249, 247, 228));
        panel_utama1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel_atas2.setBackground(new java.awt.Color(34, 78, 133));
        panel_atas2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logobulat90.png"))); // NOI18N
        jLabel12.setText("jLabel3");

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logotutwuri90.png"))); // NOI18N
        jLabel13.setText("jLabel3");

        jLabel14.setFont(new java.awt.Font("Cooper Black", 0, 36)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(249, 247, 228));
        jLabel14.setText("PENGEMBALIAN BUKU");

        javax.swing.GroupLayout panel_atas2Layout = new javax.swing.GroupLayout(panel_atas2);
        panel_atas2.setLayout(panel_atas2Layout);
        panel_atas2Layout.setHorizontalGroup(
            panel_atas2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_atas2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );
        panel_atas2Layout.setVerticalGroup(
            panel_atas2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel_atas2Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(panel_atas2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13))
                .addGap(14, 14, 14))
            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        panel_utama1.add(panel_atas2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel15.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel15.setText("Kode Pinjam          :");
        panel_utama1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 140, 30));

        jLabel16.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel16.setText("Nama Peminjam   :");
        panel_utama1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 140, 30));

        tf_kodepinjam_pengembalianbuku.setEditable(false);
        tf_kodepinjam_pengembalianbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));
        panel_utama1.add(tf_kodepinjam_pengembalianbuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 250, 170, 30));

        tf_nama_pengembalianbuku.setEditable(false);
        tf_nama_pengembalianbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));
        panel_utama1.add(tf_nama_pengembalianbuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 290, 170, 30));

        tbl_pengembalianbuku.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 12)); // NOI18N
        tbl_pengembalianbuku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Kode Pinjam", "Nama Peminjam", "Kode Buku", "Nama Buku"
            }
        ));
        jScrollPane2.setViewportView(tbl_pengembalianbuku);

        panel_utama1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 790, 140));

        btn_kembali_pengembalianbuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_kembali_pengembalianbuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_kembali_pengembalianbuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_kembali_pengembalianbuku.setText("LogOut");
        btn_kembali_pengembalianbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kembali_pengembalianbukuActionPerformed(evt);
            }
        });
        panel_utama1.add(btn_kembali_pengembalianbuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, -1, 30));

        btn_kembalikan_pengembalianbuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_kembalikan_pengembalianbuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_kembalikan_pengembalianbuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_kembalikan_pengembalianbuku.setText("Kembalikan");
        btn_kembalikan_pengembalianbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kembalikan_pengembalianbukuActionPerformed(evt);
            }
        });
        panel_utama1.add(btn_kembalikan_pengembalianbuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 510, -1, 30));

        tf_namabuku_pengembalianbuku.setEditable(false);
        tf_namabuku_pengembalianbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));
        panel_utama1.add(tf_namabuku_pengembalianbuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 290, 170, 30));

        tf_kodebuku_pengembalianbuku.setEditable(false);
        tf_kodebuku_pengembalianbuku.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(34, 78, 133)));
        panel_utama1.add(tf_kodebuku_pengembalianbuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 250, 170, 30));

        jLabel17.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel17.setText("Nama Buku         :");
        panel_utama1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 290, 140, 30));

        jPanel12.setBackground(new java.awt.Color(249, 247, 228));
        jPanel12.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray));

        jLabel25.setBackground(new java.awt.Color(204, 204, 204));
        jLabel25.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(34, 78, 133));
        jLabel25.setText("Masukkan Password");

        tf_password_pengembalianbuku.setBackground(new java.awt.Color(249, 247, 228));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel25)
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tf_password_pengembalianbuku)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tf_password_pengembalianbuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        panel_utama1.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 140, 250, 80));

        jPanel8.setBackground(new java.awt.Color(249, 247, 228));
        jPanel8.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray, java.awt.Color.lightGray));

        jLabel18.setBackground(new java.awt.Color(204, 204, 204));
        jLabel18.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(34, 78, 133));
        jLabel18.setText("Cari Kode Pinjam");

        tf_carikodepinjam_pengembalianbuku.setBackground(new java.awt.Color(249, 247, 228));

        btn_cari_pengembalianbuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_cari_pengembalianbuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_cari_pengembalianbuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_cari_pengembalianbuku.setText("Cari");
        btn_cari_pengembalianbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cari_pengembalianbukuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(tf_carikodepinjam_pengembalianbuku, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_cari_pengembalianbuku))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel18)
                        .addGap(51, 51, 51)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_carikodepinjam_pengembalianbuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_cari_pengembalianbuku))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel_utama1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 140, 250, 80));

        jLabel19.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 14)); // NOI18N
        jLabel19.setText("Kode Buku           :");
        panel_utama1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 250, 140, 30));

        btn_batal_pengembalianbuku.setBackground(new java.awt.Color(34, 78, 133));
        btn_batal_pengembalianbuku.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        btn_batal_pengembalianbuku.setForeground(new java.awt.Color(249, 247, 228));
        btn_batal_pengembalianbuku.setText("Batal");
        btn_batal_pengembalianbuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_batal_pengembalianbukuActionPerformed(evt);
            }
        });
        panel_utama1.add(btn_batal_pengembalianbuku, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 510, -1, 30));

        javax.swing.GroupLayout PPengembalianBukuLayout = new javax.swing.GroupLayout(PPengembalianBuku);
        PPengembalianBuku.setLayout(PPengembalianBukuLayout);
        PPengembalianBukuLayout.setHorizontalGroup(
            PPengembalianBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_utama1, javax.swing.GroupLayout.DEFAULT_SIZE, 810, Short.MAX_VALUE)
        );
        PPengembalianBukuLayout.setVerticalGroup(
            PPengembalianBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_utama1, javax.swing.GroupLayout.PREFERRED_SIZE, 554, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        panel_informasibuku.addTab("Pengembalian Buku", PPengembalianBuku);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_informasibuku, javax.swing.GroupLayout.PREFERRED_SIZE, 810, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel_informasibuku)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_kembali_peminjamanbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kembali_peminjamanbukuActionPerformed
        // TODO add your handling code here:
        Login loginFrame = new Login();
        loginFrame.setVisible(true);
        loginFrame.pack();
        loginFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btn_kembali_peminjamanbukuActionPerformed

    private void btn_kodepinjam_peminjamanbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kodepinjam_peminjamanbukuActionPerformed
        // TODO add your handling code here:
        autonumber();
    }//GEN-LAST:event_btn_kodepinjam_peminjamanbukuActionPerformed

    private void btn_pinjam_peminjamanbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pinjam_peminjamanbukuActionPerformed
        // TODO add your handling code here:
        PinjamBuku();
    }//GEN-LAST:event_btn_pinjam_peminjamanbukuActionPerformed

    private void btn_pilihbuku_peminjamanbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pilihbuku_peminjamanbukuActionPerformed
        // TODO add your handling code here:
        // Membuka dialog tabel buku
        DataBuku databuku = new DataBuku();
        // databuku.setVisible(true);

        // Membuat dialog pop-up
        JDialog dialog = new JDialog();
        dialog.setTitle("Tabel Buku");

        // Mendapatkan tabel dari DataBuku
        JTable tblDataBuku = databuku.getTblDataBuku();

        // Menambahkan tabel tbl_stok ke dalam JScrollPane
        JScrollPane scrollPane = new JScrollPane(tblDataBuku);
        dialog.add(scrollPane);
        
    // Tambahkan listener untuk menangkap klik pada tabel
    tblDataBuku.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent evt) {
            int selectedRow = tblDataBuku.getSelectedRow(); // Mendapatkan baris yang dipilih
            if (selectedRow != -1) {

                // Mendapatkan data dari tabel dan mengisi TextField di Input
                tf_kodebuku_peminjamanbuku.setText(tblDataBuku.getValueAt(selectedRow, 0).toString());
                tf_namabuku_peminjamanbuku.setText(tblDataBuku.getValueAt(selectedRow, 1).toString());
                tf_pengarang_peminjamanbuku.setText(tblDataBuku.getValueAt(selectedRow, 2).toString());
                tf_penerbit_peminjamanbuku.setText(tblDataBuku.getValueAt(selectedRow, 3).toString());
                tf_tahunterbit_peminjamanbuku.setText(tblDataBuku.getValueAt(selectedRow, 4).toString());
                tf_jumlah_peminjamanbuku.setText(tblDataBuku.getValueAt(selectedRow, 5).toString());
                // Menutup dialog setelah data diambil
                
                dialog.dispose();
            }
        }
    });

        // Mengatur ukuran dan menampilkan dialog
        dialog.setSize(600, 400);
        dialog.setLocationRelativeTo(null); // Memposisikan dialog di tengah layar
        dialog.setVisible(true);
    }//GEN-LAST:event_btn_pilihbuku_peminjamanbukuActionPerformed

    private void btn_kembali_pengembalianbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kembali_pengembalianbukuActionPerformed
        // TODO add your handling code here:
        Login loginFrame = new Login();
        loginFrame.setVisible(true);
        loginFrame.pack();
        loginFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btn_kembali_pengembalianbukuActionPerformed

    private void btn_caribuku_informasibukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_caribuku_informasibukuActionPerformed
        // TODO add your handling code here:
        String kataKunci = tf_carijudulbuku_pengembalianbuku.getText();

    if (kataKunci.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Tolong masukkan kata kunci untuk mencari!");
        return;
    }

    try {
        // Query untuk mencari data buku yang nama bukunya mengandung kata kunci
        String sql = "SELECT nama_buku FROM data_buku WHERE nama_buku LIKE ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, "%" + kataKunci + "%");  // Mencari nama buku yang mengandung kata kunci
        ResultSet rs = ps.executeQuery();

        // Menyusun hasil pencarian
        StringBuilder bukuDitemukan = new StringBuilder();
        while (rs.next()) {
            String namaBuku = rs.getString("nama_buku");
            bukuDitemukan.append(namaBuku).append("\n");
        }

        if (bukuDitemukan.length() > 0) {
            JOptionPane.showMessageDialog(this, "Buku yang ditemukan:\n" + bukuDitemukan.toString(), 
                                          "Informasi Pencarian", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Tidak ada buku yang sesuai dengan kata kunci tersebut.", 
                                          "Peringatan", JOptionPane.WARNING_MESSAGE);
        }
    } catch (SQLException e) {
        System.out.println("Gagal mencari data buku: " + e.getMessage());
        JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat mencari buku.", 
                                      "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btn_caribuku_informasibukuActionPerformed

    private void btn_cari_pengembalianbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cari_pengembalianbukuActionPerformed
        // TODO add your handling code here:
         String kodePinjam = tf_carikodepinjam_pengembalianbuku.getText();
    
        if (kodePinjam.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tolong masukkan kode pinjam untuk mencari!");
            return;
            }

            try {
                // Query diarahkan ke tabel peminjaman_buku
                String sql = "SELECT kode_pinjam, nama_peminjam, kode_buku2, nama_buku2 FROM peminjaman_buku WHERE kode_pinjam = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, kodePinjam);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    // Mengisi textfield dengan data yang ditemukan
                    tf_kodepinjam_pengembalianbuku.setText(rs.getString("kode_pinjam"));
                    tf_nama_pengembalianbuku.setText(rs.getString("nama_peminjam"));
                    tf_kodebuku_pengembalianbuku.setText(rs.getString("kode_buku2"));
                    tf_namabuku_pengembalianbuku.setText(rs.getString("nama_buku2"));
                } else {
                    JOptionPane.showMessageDialog(this, "Data dengan kode pinjam tersebut tidak ditemukan!");
                    resetForm();
                }
            } catch (SQLException e) {
                System.out.println("Gagal mencari data peminjaman: " + e.getMessage());
        }
    }//GEN-LAST:event_btn_cari_pengembalianbukuActionPerformed

    private void btn_kembalikan_pengembalianbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kembalikan_pengembalianbukuActionPerformed
        // TODO add your handling code here:
        KembalikanBuku();
    }//GEN-LAST:event_btn_kembalikan_pengembalianbukuActionPerformed

    private void btn_batal_pengembalianbukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_batal_pengembalianbukuActionPerformed
        // TODO add your handling code here:
        tf_kodepinjam_pengembalianbuku.setText("");
        tf_nama_pengembalianbuku.setText("");
        tf_kodebuku_pengembalianbuku.setText("");
        tf_namabuku_pengembalianbuku.setText("");
        tf_carikodepinjam_pengembalianbuku.setText("");
    }//GEN-LAST:event_btn_batal_pengembalianbukuActionPerformed

    private void btn_logout_informasibukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logout_informasibukuActionPerformed
        // TODO add your handling code here:
        Login loginFrame = new Login();
        loginFrame.setVisible(true);
        loginFrame.pack();
        loginFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btn_logout_informasibukuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new User().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel PInformasiBuku;
    private javax.swing.JPanel PPeminjamanBuku;
    private javax.swing.JPanel PPengembalianBuku;
    private javax.swing.JButton btn_batal_pengembalianbuku;
    private javax.swing.JButton btn_cari_pengembalianbuku;
    private javax.swing.JButton btn_caribuku_informasibuku;
    private javax.swing.JButton btn_kembali_peminjamanbuku;
    private javax.swing.JButton btn_kembali_pengembalianbuku;
    private javax.swing.JButton btn_kembalikan_pengembalianbuku;
    private javax.swing.JButton btn_kodepinjam_peminjamanbuku;
    private javax.swing.JButton btn_logout_informasibuku;
    private javax.swing.JButton btn_pilihbuku_peminjamanbuku;
    private javax.swing.JButton btn_pinjam_peminjamanbuku;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPanel panel_atas1;
    private javax.swing.JPanel panel_atas2;
    private javax.swing.JPanel panel_atas5;
    private javax.swing.JTabbedPane panel_informasibuku;
    private javax.swing.JPanel panel_utama1;
    private javax.swing.JPanel panel_utama4;
    private javax.swing.JTable tbl_informasibuku;
    private javax.swing.JTable tbl_peminjamanbuku;
    private javax.swing.JTable tbl_pengembalianbuku;
    private javax.swing.JTextField tf_carijudulbuku_pengembalianbuku;
    private javax.swing.JTextField tf_carikodepinjam_pengembalianbuku;
    private javax.swing.JTextField tf_jumlah_peminjamanbuku;
    private javax.swing.JTextField tf_kodebuku_peminjamanbuku;
    private javax.swing.JTextField tf_kodebuku_pengembalianbuku;
    private javax.swing.JTextField tf_kodepinjam_peminjamanbuku;
    private javax.swing.JTextField tf_kodepinjam_pengembalianbuku;
    private javax.swing.JTextField tf_nama_peminjamanbuku;
    private javax.swing.JTextField tf_nama_pengembalianbuku;
    private javax.swing.JTextField tf_namabuku_peminjamanbuku;
    private javax.swing.JTextField tf_namabuku_pengembalianbuku;
    private javax.swing.JTextField tf_nisn_peminjamanbuku;
    private javax.swing.JPasswordField tf_password_pengembalianbuku;
    private javax.swing.JTextField tf_penerbit_peminjamanbuku;
    private javax.swing.JTextField tf_pengarang_peminjamanbuku;
    private javax.swing.JTextField tf_tahunterbit_peminjamanbuku;
    // End of variables declaration//GEN-END:variables
}
